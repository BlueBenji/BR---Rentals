Config = {}

Config.QBTarget = true

Config.BlipName = "Vehicle Rental"
Config.RentalLocation = vector3(395.95, -635.72, 28.71)

Config.Vehicle1Header = "Volkwagen Polo"
Config.Vehicle1Text = "Rent This Vehicel - £50"
Config.Vehicle1Model = "vwpolo"
Config.Vehicle1Price = 50

Config.Vehicle2Header = "Toyota Prius"
Config.Vehicle2Text = "Rent This Vehicel - £100"
Config.Vehicle2Model = "prius17"
Config.Vehicle2Price = 100

-- example to copy **CHANGE THEN VEHICLE NUMBERS**

-- Config.Vehicle3Header = "Toyota Prius"
-- Config.Vehicle3Text = "Rent This Vehicel - £100"
-- Config.Vehicle3Model = "prius17"
-- Config.Vehicle3Price = 100