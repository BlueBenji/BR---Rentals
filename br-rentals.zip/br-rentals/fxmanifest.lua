fx_version 'cerulean'
games { 'gta5' }

author 'Bluebenji#0001'
description 'A vehicle rental script for the QB framework.'

shared_script 'config.lua'

client_scripts {
    'client/*.lua'
}

server_scripts {
    'server/*.lua'
}

lua54 'yes'

escrow_ignore {
    'config.lua',
    'c_main.lua',
    's_main.lua'
}